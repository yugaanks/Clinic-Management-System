package edu.stevens.cs548.clinic.domain;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2016-10-25T19:51:56.573-0400")
@StaticMetamodel(RadiologyDateValues.class)
public class RadiologyDateValues_ {
	public static volatile SingularAttribute<RadiologyDateValues, Date> date;
}
