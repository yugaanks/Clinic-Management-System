--<ScriptOptions statementTerminator=";"/>

CREATE TABLE patient (
	);

CREATE TABLE drugtreatment (
	);

CREATE TABLE message (
	);

CREATE TABLE radiology (
	);

CREATE TABLE treatment (
	);

CREATE TABLE surgery (
	);

CREATE TABLE provider (
	);

CREATE TABLE radiologydatevalue (
	);

CREATE TABLE sequence (
	);

